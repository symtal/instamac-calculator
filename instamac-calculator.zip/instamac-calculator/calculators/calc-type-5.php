
		<div class="rw">

			<label class="cl50">
				Area <span>meters sq.</span><br>
				<input type="number" id="metres-type-5" value="0" onkeyup="calculateArea();" onchange="calculateArea();">
			</label>

		</div>

		<input type="hidden" id="product-unit-type" value="<?php echo $find_item->PerKG; ?>">
	