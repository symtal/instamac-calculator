
		<div class="rw">

			<label class="cl50">
				Linear Metres <span>meters</span><br>
				<input type="number" id="metres-type-3" value="0" onkeyup="calculateLinearMetre();" onchange="calculateLinearMetre();">
			</label>

		</div>

		<input type="hidden" id="product-unit-type" value="<?php echo $find_item->PerKG; ?>">
